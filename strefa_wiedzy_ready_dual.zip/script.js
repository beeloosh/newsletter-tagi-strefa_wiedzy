async function renderNews(limit=3){
  const box = document.getElementById('news');
  if(!box) return;
  try{
    const resp = await fetch('news.json', {cache:'no-cache'});
    const items = await resp.json();
    items.sort((a,b)=> a.date < b.date ? 1 : -1);
    const slice = items.slice(0, limit);
    box.innerHTML = slice.map(n => `
      <div class="news-card">
        <div class="catline">${n.category || ''}</div>
        <div class="body">
          <h4>${n.title}</h4>
          <p class="small">${n.date}</p>
          <p>${n.summary || ''}</p>
          <a class="btn" href="${n.url || '#'}">Czytaj</a>
        </div>
      </div>`).join('');
  } catch(e){
    box.innerHTML = '<p>Nie udało się załadować aktualności.</p>';
    console.error(e);
  }
}
document.addEventListener('DOMContentLoaded', ()=> renderNews(3));