// Preferences
const PREF_FONT='sw_font_scale'; const PREF_CONTRAST='sw_contrast';

function applyFontScale(scale){ document.documentElement.style.fontSize=(18*scale)+'px'; localStorage.setItem(PREF_FONT,String(scale)); }
function setContrast(on){ document.body.classList.toggle('hc',!!on); const t=document.getElementById('toggle-contrast'); if(t) t.setAttribute('aria-pressed', on?'true':'false'); localStorage.setItem(PREF_CONTRAST, on?'1':'0'); }

function initA11y(){
  const sm=document.getElementById('font-smaller');
  const rs=document.getElementById('font-reset');
  const bg=document.getElementById('font-bigger');
  const ct=document.getElementById('toggle-contrast');

  const savedScale=parseFloat(localStorage.getItem(PREF_FONT)||'1');
  const savedContrast=localStorage.getItem(PREF_CONTRAST)==='1';
  applyFontScale(savedScale); setContrast(savedContrast);

  sm?.addEventListener('click', ()=> applyFontScale(Math.max(0.8,(parseFloat(localStorage.getItem(PREF_FONT)||'1')-0.1)).toFixed(2)));
  rs?.addEventListener('click', ()=> applyFontScale(1));
  bg?.addEventListener('click', ()=> applyFontScale(Math.min(1.6,(parseFloat(localStorage.getItem(PREF_FONT)||'1')+0.1)).toFixed(2)));
  ct?.addEventListener('click', ()=> setContrast(!document.body.classList.contains('hc')));
}

// Aktualności
async function renderNews(limit=3){
  const box=document.getElementById('news');
  if(!box) return;
  try{
    const r=await fetch('data/news.json',{cache:'no-cache'});
    const items=await r.json();
    items.sort((a,b)=> a.date<b.date?1:-1);
    box.innerHTML=items.slice(0,limit).map(n=>`<article class="news-card"><div class="catline">${n.category||''}</div><div class="body"><h4>${n.title}</h4><p class="small">${n.date}</p><p>${n.summary||''}</p>${n.url?`<a class="btn" href="${n.url}">Czytaj</a>`:''}</div></article>`).join('');
  }catch(e){ box.innerHTML='<p>Nie udało się załadować aktualności.</p>'; }
}

// Słówko dnia z puli tematu miesiąca
async function renderWordOfDay(){
  const termEl=document.getElementById('wod-term');
  const defEl=document.getElementById('wod-def');
  const topicTitle=document.getElementById('topic-title');
  const topicDesc=document.getElementById('topic-desc');
  if(!termEl || !defEl) return;
  try{
    const cfg=await (await fetch('data/config.json',{cache:'no-cache'})).json();
    const w=await (await fetch('data/words.json',{cache:'no-cache'})).json();
    const pool=w.filter(x=>x.cat===cfg.topic_of_month.key);
    const idx=Math.abs(Math.floor(new Date()/(1000*60*60*24))) % (pool.length || 1);
    const word=pool[idx] || {term:'Profil Zaufany', def:'Bezpłatny klucz elektroniczny do potwierdzania tożsamości w Internecie.'};
    termEl.textContent=word.term; defEl.textContent=word.def;
    if(topicTitle) topicTitle.textContent = cfg.topic_of_month.title;
    if(topicDesc) topicDesc.textContent = cfg.topic_of_month.description;
  }catch(e){
    termEl.textContent='Profil Zaufany';
    defEl.textContent='Bezpłatny klucz elektroniczny do potwierdzania tożsamości w Internecie.';
  }
}

// Akordeony
function initAccordions(){
  document.querySelectorAll('.accordion-button').forEach(btn=>{
    btn.addEventListener('click', ()=> togglePanel(btn));
    btn.addEventListener('keydown', (e)=>{ if(e.key===' '||e.key==='Enter'){ e.preventDefault(); togglePanel(btn); } });
  });
}
function togglePanel(btn){
  const id=btn.getAttribute('aria-controls');
  const panel=document.getElementById(id);
  const expanded=btn.getAttribute('aria-expanded')==='true';
  btn.setAttribute('aria-expanded', String(!expanded));
  panel?.classList.toggle('open', !expanded);
}

// Słownik – prosta lista
async function renderDictionary(){
  const box=document.getElementById('dict');
  if(!box) return;
  try{
    const data=await (await fetch('data/words.json',{cache:'no-cache'})).json();
    box.innerHTML = data.map(x => `<dt>${x.term}</dt><dd>${x.def} <span class="muted">[${x.cat}]</span></dd>`).join('');
  }catch(e){
    box.innerHTML = '<p>Nie udało się załadować słownika.</p>';
  }
}

// Stories form
function initStoriesForm(){
  const form=document.getElementById('story-form'), list=document.getElementById('story-list'), ok=document.getElementById('ok');
  if(!form||!list) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const text=document.getElementById('story').value.trim();
    const author=document.getElementById('author').value.trim();
    if(text.length<10){ ok.textContent='Napisz kilka zdań (min. 10 znaków).'; return; }
    const card=document.createElement('article'); card.className='story-card';
    card.innerHTML='<h3>„Swoimi słowami”</h3><p>'+text.replace(/</g,'&lt;')+'</p>'+(author?'<p class="author">— '+author.replace(/</g,'&lt;')+'</p>':'');
    list.prepend(card); ok.textContent='Dziękujemy! Dodano wpis (lokalnie w tej przeglądarce).'; form.reset();
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  initA11y();
  renderNews(3);
  renderWordOfDay();
  initAccordions();
  renderDictionary();
  initStoriesForm();
});
