// placeholder


async function renderAktualnosci(targetId, limit=null){
  try{
    const resp = await fetch('news.json', {cache: 'no-cache'});
    const items = await resp.json();
    // sortuj po dacie malejąco
    items.sort((a,b)=> (a.date < b.date) ? 1 : -1);
    const slice = limit ? items.slice(0, limit) : items;
    const target = document.getElementById(targetId);
    if(!target) return;
    target.innerHTML = slice.map(n => `
      <div class="card">
        <h3>${n.title}</h3>
        <p class="badge">${n.category}</p>
        <p class="notice">${n.date}</p>
        <p>${n.summary}</p>
        <p><a href="${n.url}">Czytaj więcej →</a></p>
      </div>
    `).join('');
  }catch(e){
    console.error(e);
  }
}

document.addEventListener('DOMContentLoaded',()=>{ if (typeof renderAktualnosci==='function'){ renderAktualnosci('aktualnosci-home',6); } });
